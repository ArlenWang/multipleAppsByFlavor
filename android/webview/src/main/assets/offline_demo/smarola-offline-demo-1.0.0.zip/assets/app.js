document.querySelector('#verify').addEventListener('click', async () => {
  const output = document.querySelector('#result');
  try {
    const response = await fetch('data/status.json');
    const data = await response.json();
    output.textContent = `成功：${data.message}\n版本：${data.version}\n时间：${new Date().toLocaleTimeString()}`;
  } catch (error) {
    output.textContent = `失败：${error}`;
  }
});
